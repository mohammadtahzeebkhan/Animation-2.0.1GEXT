self.__precacheManifest = [
  {
    "revision": "257034ad9969d29c8eb6",
    "url": "css/app.2c8c6f5b.css"
  },
  {
    "revision": "257034ad9969d29c8eb6",
    "url": "js/app.beadc05a.js"
  },
  {
    "revision": "7ff7be51b469c811d168",
    "url": "css/chunk-vendors.bb2804aa.css"
  },
  {
    "revision": "7ff7be51b469c811d168",
    "url": "js/chunk-vendors.38905c35.js"
  },
  {
    "revision": "cb9242146b549ee99fc753f2417d926a",
    "url": "img/3d.cb924214.svg"
  },
  {
    "revision": "5ea441965539ecd9f8db53e754ce2c24",
    "url": "img/vace.5ea44196.png"
  },
  {
    "revision": "27bd200350ba680180b17592b533a392",
    "url": "img/crosshair.27bd2003.svg"
  },
  {
    "revision": "97a41d837f3e71183af44cb0770e0dd9",
    "url": "img/effects.97a41d83.svg"
  },
  {
    "revision": "f7cb09199dd2afa8005e4b170cca4066",
    "url": "img/2d.f7cb0919.svg"
  },
  {
    "revision": "f050cb1361ad2b5d1b7c187035318a16",
    "url": "img/logo.f050cb13.svg"
  },
  {
    "revision": "05acfdb568b3df49ad31355b19495d4a",
    "url": "fonts/ionicons.05acfdb5.woff"
  },
  {
    "revision": "2c2ae068be3b089e0a5b59abb1831550",
    "url": "fonts/ionicons.2c2ae068.eot"
  },
  {
    "revision": "24712f6c47821394fba7942fbb52c3b2",
    "url": "fonts/ionicons.24712f6c.ttf"
  },
  {
    "revision": "621bd386841f74e0053cb8e67f8a0604",
    "url": "img/ionicons.621bd386.svg"
  },
  {
    "revision": "1d54755686aa727a2ecd0ca7d34b348a",
    "url": "index.html"
  },
  {
    "revision": "8474d1fb892fae7d032c8d4558ffe6b9",
    "url": "devtools/content-script.js"
  },
  {
    "revision": "8ffaa217d1dd63cdb51bb54ae14dc5a0",
    "url": "devtools/devtools.html"
  },
  {
    "revision": "14b9107dfeefd7b95eb0da02f266fd61",
    "url": "devtools/devtools.js"
  },
  {
    "revision": "6663438fce0ef517c3e3e1afcff7fbba",
    "url": "devtools/popup.html"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "robots.txt"
  },
  {
    "revision": "73bb6a248d1581f238f36178ed68417e",
    "url": "static/128.png"
  },
  {
    "revision": "9bb3da2a2e6b407ef177ec8039a7219c",
    "url": "static/16.png"
  },
  {
    "revision": "085fc796b38c4b9fa516ee5b34c8a293",
    "url": "static/32.png"
  },
  {
    "revision": "a5f34c2c29aa258f1db83c2f61b6f612",
    "url": "static/19.png"
  },
  {
    "revision": "65f40ed6278003fecfd89aa5f24d8d75",
    "url": "static/64.png"
  },
  {
    "revision": "2aa78eb28493c94034a3b6803932c388",
    "url": "static/38.png"
  },
  {
    "revision": "f5ecce3b56378a61e87a7b6096132e6b",
    "url": "static/500.png"
  },
  {
    "revision": "0f202359cb22eab01c278ea21894f47c",
    "url": "static/48.png"
  },
  {
    "revision": "4e0f95c3b41222b1ca7595b7e4e50847",
    "url": "static/preload.css"
  },
  {
    "revision": "c8bc33a1eb9c322d3abf4304d1208b7c",
    "url": "webapp.json"
  },
  {
    "revision": "f050cb1361ad2b5d1b7c187035318a16",
    "url": "static/logo.svg"
  }
];