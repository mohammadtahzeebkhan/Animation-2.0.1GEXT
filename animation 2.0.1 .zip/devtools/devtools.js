'use strict';
/* global chrome */
chrome.devtools.panels.elements.createSidebarPane('Animation', sidebar => {
  sidebar.setPage('index.html');
})
