// /* global chrome */
// https://crxdoc-zh.appspot.com/extensions/content_scripts

(function () {

  /**
   * @const
   * 序列化选择器时的最大层级
   */
  const MAX_SELECTOR_LEVEAL = 3
  /**
   * @const
   * 全局hook名称
   */
  const HOOK_KEY = '__NICEAPP_ANIMATION'

  /**
   * @const
   * 全局动画元素key
   */
  const ELEMENT_KEY = '__ani_id__'

  /**
   * @const
   * 动画前缀，对于匹配到的动画前缀直接使用
   */
  const ANIMTION_PREFIX_CLASS = /^(x-|c3|vp|_vp|ani)-/i

  /**
   * @const
   * 不支持动画属性的标签列表
   */
  const DISABLED_ANIMATION_TAGS = 'head,meta,title,link,style,script,base,noscript,template'.split(',')

  if (window[HOOK_KEY]) {
    return
  }

  /**
   * @const 
   * 保存全部动画队列
   */
  const ALL_PROXY_ELEMENTS = []

  // 初始化
  function initApplication (initParams, element) {
    return proxy(element).toObject()
  }

  /**
   * 向当前页面插入css3 keyframes
   * 
   * @param {string} keyframesCode 动画代码
   */
  function insertKeyframes (keyframesCode) {
    return proxyStyle('keyframes').addCode(keyframesCode)
  }

  /**
   * 向当前文档插入css代码
   * 
   * @param {any} cssText 
   */
  function insertCssText (cssText) {
    return proxyStyle('css').addCode(cssText)
  }
  
  /**
   * 当前元素更改动画属性
   */
  function changeAnimation({ keyframesText, cssText }, element) {
    // 向dom中插入keyframes
    insertKeyframes(keyframesText)
    // 代理当前元素
    return proxy(element).updateAnimation(cssText).toObject()
  }
  
  // 移除当前选择的元素动画
  function removeSelectAnimation(ignore, element) {
    return proxy(element).destory().toObject()
  }

  /**
   * 清空所有的动画
   */
  function clearAllAnimation () {
    // fixed 倒序删除
    for (var _len = ALL_PROXY_ELEMENTS.length - 1; _len >= 0; _len--) {
      var element = ALL_PROXY_ELEMENTS[_len]
      element.destory()
    }
  }

  // 预览全部动画
  function previewAllAnimation () {
    for (var _len = ALL_PROXY_ELEMENTS.length - 1; _len >= 0; _len--) {
      var element = ALL_PROXY_ELEMENTS[_len]
      element.replay()
    }
  }

  /**
   * 重新播放当前元素动画
   */
  function replayAnimation (ignore, element) {
    return proxy(element).replay().toObject()
  }

  /**
   * @member {Hook}
   * 更改元素，返回元素动画配置结构
   */
  function changeElement (cmd, element) {
    return proxy(element).toObject()
  }

  window[HOOK_KEY] = {
    initApplication,
    changeElement,
    changeAnimation,
    insertKeyframes,
    insertCssText,
    removeSelectAnimation,
    clearAllAnimation,
    replayAnimation,
    previewAllAnimation
  }

  let _id = 1  
  /**
   * 管理动画元素
   * 
   * @param {HtmlElement} element 
   * @returns {_ElementProxy}
   */
  function proxy (element) {
    if (element[ELEMENT_KEY]) {
      return element[ELEMENT_KEY]
    }
    return new _ElementProxy(element)
  }

  function _ElementProxy (element) {
    /* 只有 elemnet 节点可以添加动画 */
    let tagName = element.tagName ? (element.tagName.toLowerCase()) : 'Comment'
    let valid = this.valid = element.nodeType === Node.ELEMENT_NODE && DISABLED_ANIMATION_TAGS.indexOf(tagName) === -1
    
    /* 元素唯一ID */
    this.id = valid ? _id++ : 0
    /* 当前元素实例 */
    this.element = element
    /* 序列化的元素选择器 */
    this.selector = valid ? selector(element) : `[${tagName} element invalid]`
    /* 是否是第一次选择 */
    this.first = true
    /* 给元素生成选择器id */
    this.attrId = ''
    /* 绑定实例到元素 */
    element[ELEMENT_KEY] = this
    /* 构建唯一属性 */
    // this.updateAttrId()
    if (valid) {
      ALL_PROXY_ELEMENTS.push(this)
    }
  }
  _ElementProxy.prototype = {
    // 构建唯一id，在生成动画时使用
    updateAttrId () {
      if (!this.valid) {
        return 
      }
      if (this.attrId) {
        this.element.removeAttribute(this.attrId)
      }
      this.attrId = 'ani-' + nextUid()
      this.element.setAttribute(this.attrId, '')
      return this
    },
    // 更新当前元素的动画代码
    updateAnimation (cssCode) {
      if (!this.valid) {
        return this
      }
      // 更新动画
      this.updateAttrId()
      this.animationCode = cssCode
      let code = `${this.selector}[${this.attrId}] {${cssCode}}`
      // remove old style node
      if (this.node) {
        this.node.remove()
      }
      setTimeout(() => {
        this.node = insertCssText(code)
      }, 0)
      return this
    },
    toObject () {
      let { id, selector, first, attrId } = this
      return { id, selector, first, attrId }
    },
    replay () {
      if (!this.valid || !this.node) {
        return this
      }
      return this.updateAnimation(this.animationCode)
    },
    // 移除动画
    destory () {
      if (!this.valid) {
        return this
      }
      this.element.removeAttribute(this.attrId)
      if (this.node) {
        this.node.remove()
      }
      // remove in queue
      var index = ALL_PROXY_ELEMENTS.indexOf(this)
      if (index !== -1) {
        ALL_PROXY_ELEMENTS.splice(index, 1)
      }
      return this
    }
  }
  /**
   * 获取元素的选择器结构
   * 
   * @param {HtmlElement} element 
   */
  function selector (element, leavel = 1) {
    let classList = element.classList
    let className, classSelector
    for (let i = classList.length - 1; i >= 0; i--) {
      className = classList.item(i)
      classSelector = `.${className}`
      if (ANIMTION_PREFIX_CLASS.test(className)) {
        return classSelector
      }
    }
    // 优先返回元素id
    if (element.id) {
      return `#${element.id}`
    }
    let tagName = element.tagName.toLowerCase()
    if (tagName === 'body' || tagName === 'html') {
      return tagName
    }
    if (!classSelector) {
      classSelector = tagName
    }
    if (leavel < MAX_SELECTOR_LEVEAL && element.parentNode) {
      // fixed 优先返回设置的class
      return selector(element.parentNode, leavel + 1) + ' > ' + classSelector
    }
    return classSelector
  }

  let _0x1000 = 0x1000
  function nextUid() {
    return (_0x1000++).toString(16)
  }

  let _styleElementCache = Object.create(null)
  let _keyframesInsertsMap = Object.create(null)
  const _keyframesMatchs = /@keyframes(.*?){/ig
  function proxyStyle (id) {
    if (!_styleElementCache[id]) {
      let element = document.createElement('style')
      let parent = document.querySelector('head') || document.querySelector('body')
      // settinf
      element.type = 'text/css'
      element.setAttribute('data-title', 'chrome-extention-animation-' + id)
      parent.appendChild(element)
      let manager = {
        // 返回代码节点
        addCode: function (code) {
          // 确保code是否包含keyframes，插入一次就可以了
          if (_keyframesMatchs.test(code)) {
            let keyframesName = RegExp.$1.trim().toLowerCase()
            if (_keyframesInsertsMap[keyframesName]) {
              return true
            }
            _keyframesInsertsMap[keyframesName] = true
          }
          var node = document.createTextNode(code)
          element.appendChild(node)
          return node
        }
      }
      _styleElementCache[id] = manager
    }
    return _styleElementCache[id]
  }
})();
